A Pen created at CodePen.io. You can find this one at http://codepen.io/jlong64/pen/jwJpc.

 Some simple dynamic lightning bolts done in canvas.